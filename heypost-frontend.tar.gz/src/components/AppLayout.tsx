import { useEffect } from "react";
import { BarChart3, Package, ReceiptText, ShoppingBag } from "lucide-react";
import { NavLink, Outlet, useLocation } from "react-router";

const navigation = [
  { to: "/", label: "Kasir", icon: ShoppingBag },
  { to: "/transaksi", label: "Transaksi", icon: ReceiptText },
  { to: "/produk", label: "Produk", icon: Package },
  { to: "/laporan", label: "Laporan", icon: BarChart3 },
];

export default function AppLayout() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo({ top: 0, behavior: "instant" }); }, [pathname]);
  return (
    <div className="app-shell">
      <aside className="side-nav">
        <NavLink to="/" className="wordmark" aria-label="heypost, ke kasir">hey<span>post</span><b>.</b></NavLink>
        <nav className="desktop-menu" aria-label="Navigasi utama">
          <p>RUANG KERJA</p>
          {navigation.map(({ to, label, icon: Icon }) => <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => isActive ? "active" : ""}><Icon size={19} /><span>{label}</span></NavLink>)}
        </nav>
      </aside>
      <main className="main-workspace"><Outlet /></main>
      <nav className="bottom-nav" aria-label="Navigasi utama">
        {navigation.map(({ to, label, icon: Icon }) => <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => isActive ? "active" : ""}><Icon size={21} /><span>{label}</span></NavLink>)}
      </nav>
    </div>
  );
}
